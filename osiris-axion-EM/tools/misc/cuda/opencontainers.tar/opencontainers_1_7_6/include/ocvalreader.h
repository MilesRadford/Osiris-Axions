#ifndef VALREADER_H_

// NOTE: Due to weird include dependencies, this file includes nothing
// itself.  If you wish to use it, make sure you include ocval.h
// first.

// A class to help read "human-readable" strings of Vals (Tabs, Arrs,
// numbers, Numeric arrays).  Format is straight-forward:
//
//   ValReader v(" { 'a':'nice', 'table':1 }");
//   Tab t;
//   v.expectTab(t);
//
// From Files (streams):
//   StreamValReader sv(istream& is);
//   Tab t;
//   sv.expectTab(t);
//
// The constructors of Tab and Arr have been augmented so as to allow
// easier construction:
//   
//   Tab t = "{ 'a':1, 'b':2, 'c':3, 'list':[1,2,3] }";
//   Arr a = "[ 'a', 2, 3.3, (1+2j), { 'empty':'ish' } ]";

#include "ocstringtools.h"
#include "ocreader.h"


// Abstract base class: All the code for parsing the letters one by
// one is here.  The code for actually getting the letters (from a
// string, stream, etc.) defers to the derived class.

class ValReaderA { 

 public: 

  ValReaderA (ReaderA* adopted_reader) :
    reader_(adopted_reader) { }

  virtual ~ValReaderA () { delete reader_; }

  // Expect any number (including complex)
  void expectNumber (Val& n)
  {
    consumeWS_();
    int c=peekChar_();
    if (c=='(') {
      expectComplex_(n);
      return;
    }

    // Get the integer part, if any, of the number
    Str integer_part = getSignedDigits_('.');

    // Get the fractional part, if any
    Str fractional_part;
    c = peekChar_();
    if (c=='.') {     
      c = getChar_(); // consume the '.'
      fractional_part = "."+getDigits_();
      if (fractional_part.length()==1) { 
	const int i_len = integer_part.length();
	if (i_len==0 || (i_len>0 && !isdigit(integer_part[i_len-1]))) {
	  syntaxError_("Expecting some digits after a decimal point, but saw '"+saw_(peekChar_())+"'");
	}
      }
      c = peekChar_();
    }

    // Get the exponent part, if any
    Str exponent_part;
    if (c=='e' || c=='E') {
      c = getChar_();  // consume the 'e'
      exponent_part = "e"+getSignedDigits_(' ');
      if (exponent_part.length()==1) { // only an e
	char t[2]; t[0] = peekChar_(); t[1]='\0';
	syntaxError_("Expected '+', '-' or digits after an exponent, but saw '"+saw_(peekChar_())+"'");
      }
      c = peekChar_();
    }

    // At this point, we are (mostly) finished with the number, and we
    // have to build the proper type of number.
    if (fractional_part.length()>0 || exponent_part.length()>0) {
      // If we have either a fractional part or an exponential part,
      // then we have a floating point number
      Str stringized_number = integer_part+fractional_part+exponent_part;
      Val inside = stringized_number; 
      real_8 num = inside; // Convert out of Val to change from string 
      n = num;
      return;
    }
    
    // Well, no fractional part or exponential.  There had better be
    // some digits!
    if (integer_part.length()==0 || 
	(integer_part.length()>0 && 
	 !isdigit(integer_part[integer_part.length()-1])))
      syntaxError_("Expected some digits for a number");
	
    c=peekChar_();
    Val v = integer_part;
    if (c=='l' || c=='L') { // Okay, it's a long
      getChar_();  // consume long
      if (integer_part[0]=='-') {
	int_8 long_int = v;
	n = long_int;
	return;
      } else {
	int_u8 long_int = v;
	n = long_int;
	return;
      } 
    } else { // plain integer
      int_4 plain_int = v;
      n = plain_int;

      // In case didn't convert well
      if (plain_int==0) {
        bool all_zeroes = true;
        for (int ii=0; ii<integer_part.length(); ii++) {
          if (isdigit(integer_part[ii]) && integer_part[ii]!='0') {
            all_zeroes = false;
          }
        }
        if (all_zeroes) return;  // All good
        // Otherwise, reconsider how to parse this large number
        int_8 big_plain = v;
        n = big_plain;
                                                                                
        if (big_plain!=0) return;  // Parsed okay ...
        // Otherwise, try a double
        real_8 big_d = v;
        n = big_d;
        return;
      }
      return;
    }
  }

  // Read a string from the current place in the input
  void expectStr (Str& s)
  { 
    consumeWS_();

    char quote_mark = peekNWSChar_();
    if (quote_mark!='\'' && quote_mark!='"') {
      syntaxError_("A string needs to start with ' or \"");
    }

    expect_(quote_mark); // Start quote

    // Read string, keeping all escapes, and let DeImage handle escapes
    Array<char> a(80);
    for (int c=getChar_(); c!=quote_mark; c=getChar_()) {
      if (c==EOF) syntaxError_("Unexpected EOF inside of string");
      a.append(c);
      if (c=='\\') { // escape sequence
	int next = getChar_(); // Avoid '
	if (next==EOF) syntaxError_("Unexpected EOF inside of string");
	a.append(next);
      } 
    }    
    string temp = string(a.data(), a.length());
    string ss = DeImage(temp, false); // Do escapes 
    s = Str(ss.data(), ss.length());
  }

  // Expect Table on the input
  void expectTab (Tab& table)
  {
    expect_('{');
    
    // Special case, empty Table
    char peek = peekNWSChar_();
    if (peek!='}') {
      
      for (;;) { // Continue getting key value pairs
	Val key;   expectAnything(key);
	expect_(':');
	Val value; expectAnything(value); 
	
	table[key] = value;
	
	char peek = peekNWSChar_();
	if (peek==',') {
	  expect_(',');         // Another k-v pair, grab comma and move on
	  peek = peekNWSChar_();
          if (peek=='}') break;  // CAN have extra , at the end of the table
	  continue;
	} else if (peek=='}') { // End of table
	  break;
	} else {
	  syntaxError_("Expecting a '}' or ',' for table, but saw '"+saw_(peek)+"'");
	}
      }
    }
    expect_('}');
  }

  // Expect an Arr
  void expectArr (Arr& a)
  {
    expect_('[');
    
    // Special case, empty list
    char peek = peekNWSChar_();
    if (peek!=']') {
      
      // Continue getting each item one at a time
      while (1) {    
	a.append(Val());
	expectAnything(a[a.length()-1]); 
	
	char peek = peekNWSChar_();
	if (peek==',') {
	  expect_(',');
	  peek = peekNWSChar_();
          if (peek==']') break;  // CAN have extra , at the end of the table
	  continue;
	} else if (peek==']') {
	  break;
	} 
      }
    }
    expect_(']');
  }

  // Read in a Numeric Array
  void expectNumericArray (Val& a)
  {
    consumeWS_();
    expect_("array([");
    a = Array<int_4>(); // By default, int array

    // Special case, empty list
    char peek = peekNWSChar_();
    if (peek!=']') {
      
      Val n;
      expectNumber(n); 
	
      if (n.tag=='l') readNumericArray_<int_4>(a, n);
      else if (n.tag=='D') readNumericArray_<complex_16>(a, n);
      else if (n.tag=='d') readNumericArray_<real_8>(a, n);
      else syntaxError_("Only support Numeric arrays of cx16, real_8, and int_4");
    }
    expect_("])");
  }


  // We could be starting ANYTHING ... we have to dispatch to the
  // proper thing
  void expectAnything (Val& v)
  {
    char c = peekNWSChar_();
    switch (c) {
    case '{' : { v = Tab(); Tab& table = v; expectTab(table);      break; }
    case '[' : { v = Arr(); Arr& arr = v;   expectArr(arr);        break; }
    case '\'':
    case '"' : {            Str s = "";     expectStr(s); v=s;     break; }
    case 'a' : {                            expectNumericArray(v); break; }
    case 'N' : { v = Val(); expect_("None");                       break; }
    case 'T' : { v = true;  expect_("True");                       break; }
    case 'F' : { v = false; expect_("False");                      break; }
    default:   { v = Val();                 expectNumber(v);       break; }
    }
    
  }


 protected:


  // Helper Methods
  void syntaxError_ (const string& s) 
  {
    reader_->syntaxError(s);
  }

  string saw_ (int cc)
  {
    if (cc==EOF) return "EOF";
    char s[2] = { 0 }; 
    s[0] = cc;
    return string(s);
  }

  void expect_ (char expected)
  {
    // Single character token
    int get      = getNWSChar_();
    if (get!=expected) {
      string get_string, expected_string;
      if (get==EOF) get_string="EOF"; else get_string=get;
      expected_string = expected;
      syntaxError_("Expected:'"+expected_string+"', but saw '"+get_string+"' "
		   "on input");
    }
  }

  void expect_ (const string& s)
  {
    for (int ii=0; ii<s.length(); ii++) 
      expect_(s[ii]);
  }

  // Expect a complex number:  assumes it will have form (#+#j)
  void expectComplex_ (Val& n)
  {
    complex_16 result;
    expect_('(');
    Val real_part, imag_part;
    expectNumber(real_part);
    char c=peekChar_();
    if (c=='+' || c=='-') {
      expectNumber(imag_part);
    }
    expect_("j)");

    result.re = real_part;
    result.im = imag_part;
    n = result;
  }

  // From current point of input, consume all digits until
  // next non-digit.  Leaves non-digit on input
  Str getDigits_ ()
  {
    Str digits;
    while (1) {
      int c = peekChar_();
      if (c==EOF) 
	break;
      if (isdigit(c)) {
	digits+=char(c);
	getChar_();
      }
      else 
	break;
    }
    return digits;
  }

  // From current point in input, get the signed sequence of 
  // digits
  Str getSignedDigits_ (char next_marker)
  {
    // Get the sign of the number, if any
    char c=peekChar_();
    Str sign;
    if (c=='+'||c=='-') {
      sign = c;
      getChar_();    // consume the sign
      c=peekChar_(); // .. and see what's next
    }

    // Assertion: passed sign, now should see number or .
    if (!isdigit(c)&&c!=next_marker) {
      syntaxError_("Expected numeric digit or '"+saw_(next_marker)+"' for number, but saw '"+saw_(c)+"'");
    }
    
    Str digits = sign+getDigits_();
    return digits;
  }
  
  template <class T>
  void readNumericArray_ (Val& arr, const Val& first_value)
  { 
    arr = Array<T>();  // initialize the array
    Array<T>& a = arr; // .. then a reference to it
    T v = first_value;
    a.append(v);
    
    // Continue getting each item one at a time
    while (1) {
      char peek = peekNWSChar_();
      if (peek==',') {
	expect_(',');
	continue;
      } else if (peek==']') {
	break;
      } 

      Val n; 
      expectNumber(n);
      T v = n;
      a.append(v);
    }
  }


  // Dispatch for input
  int getNWSChar_ ()  { return reader_->getNWSChar_(); }
  int peekNWSChar_ () { return reader_->peekNWSChar_(); }
  int getChar_ ()     { return reader_->getChar_(); }
  int peekChar_ ()    { return reader_->peekChar_(); }
  int consumeWS_ ()   { return reader_->consumeWS_(); }

  // Defer IO to another class.  All sorts of discussion on why
  // didn't we inherit, etc.  Look at the Design Patterns book.
  ReaderA* reader_; 

}; // ValReaderA


// The ValReader reads Vals from strings.  The most common usage is to
// use this to read literal constants for the constructors of Tab and
// Arr.
class ValReader : public ValReaderA {

 public:

  ValReader (Array<char>& a) :
    ValReaderA(new StringReader(a))
  { }

  ValReader (const char* s) :
    ValReaderA(new StringReader(s))
  { }


 protected:

}; // ValReader


// Read a val from a stream
class StreamValReader : public ValReaderA {

 public:

  // Open the given file, and attempt to read Vals out of it
  StreamValReader (istream& is) :
    ValReaderA(new StreamReader(is))
  { }

}; // StreamValReader


// Read the given Tab from a file:  if there are any problems, throw
// a runtime_error indicating we had trouble reading the file, or a 
// logic_error if the input is malformed.
inline void ReadTabFromFile (const string& filename, Tab& t)
{
  ifstream ifs(filename.c_str());
  if (ifs.good()) {
    StreamValReader sv(ifs);
    sv.expectTab(t);
  } else {
    throw runtime_error("Trouble reading file:"+filename);
  }
}


// Write the given Tab to a file:  if there are problems, throw
// a runtime_error indicating we had trouble writing out the file.
inline void WriteTabToFile (const Tab& t, const string& filename)
{
  ofstream ofs(filename.c_str());
  if (ofs.good()) {
    t.prettyPrint(ofs);
  } else {
    throw runtime_error("Trouble writing the file:"+filename);
  }
}



#define VALREADER_H_
#endif // VALREADER_H_


